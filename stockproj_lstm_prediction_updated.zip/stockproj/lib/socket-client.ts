/** Socket.IO client configuration and hooks */
import { useEffect, useState, useCallback } from 'react'
import { io, Socket } from 'socket.io-client'

let socketInstance: Socket | null = null

export function useSocket() {
  const [socket, setSocket] = useState<Socket | null>(null)

  useEffect(() => {
    if (!socketInstance) {
      socketInstance = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:5000', {
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: 5,
      })

      socketInstance.on('connect', () => {
        console.log('[Socket] Connected to realtime server')
      })

      socketInstance.on('disconnect', () => {
        console.log('[Socket] Disconnected from realtime server')
      })

      socketInstance.on('error', (error) => {
        console.error('[Socket] Error:', error)
      })
    }

    setSocket(socketInstance)

    return () => {
      // Keep socket alive across component remounts
    }
  }, [])

  return socket
}

export interface MarketStatus {
  isOpen: boolean
  status: 'open' | 'closed' | 'pre-open' | 'after-hours'
  currentTime: string
  formattedStatus: string
}

export interface StockLiveData {
  symbol: string
  ltp: number
  change: number
  changePercent: number
  bid: number
  ask: number
  volume: number
  timestamp: string
}

/**
 * Hook to get market status
 */
export function useMarketStatus() {
  const socket = useSocket()
  const [marketStatus, setMarketStatus] = useState<MarketStatus | null>(null)

  useEffect(() => {
    if (!socket) return

    const handleMarketStatus = (status: MarketStatus) => {
      setMarketStatus(status)
    }

    socket.on('market-status', handleMarketStatus)

    return () => {
      socket.off('market-status', handleMarketStatus)
    }
  }, [socket])

  return marketStatus
}

/**
 * Hook to subscribe to a stock's live updates
 */
export function useStockLiveData(symbol: string | null) {
  const socket = useSocket()
  const [liveData, setLiveData] = useState<StockLiveData | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!socket || !symbol) {
      setIsLoading(false)
      return
    }

    setIsLoading(true)

    const handleStockUpdate = (data: StockLiveData) => {
      if (data.symbol === symbol) {
        setLiveData(data)
        setIsLoading(false)
      }
    }

    socket.on('stock-update', handleStockUpdate)
    socket.emit('subscribe-stock', symbol)

    return () => {
      socket.off('stock-update', handleStockUpdate)
      socket.emit('unsubscribe-stock', symbol)
    }
  }, [socket, symbol])

  return { liveData, isLoading }
}
