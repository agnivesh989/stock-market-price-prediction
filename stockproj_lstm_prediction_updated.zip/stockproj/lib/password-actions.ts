'use server'

import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export async function resetPasswordWithEmail(email: string) {
  const supabase = await createClient()
  
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/auth/reset-password`,
    })

    if (error) throw error
    
    return { success: true, message: 'Password reset link sent to your email' }
  } catch (error) {
    return { success: false, message: error instanceof Error ? error.message : 'Failed to send reset link' }
  }
}

export async function updatePassword(newPassword: string, currentPassword: string) {
  const supabase = await createClient()
  
  try {
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user?.email) {
      throw new Error('User not authenticated')
    }

    // Verify current password by attempting to re-authenticate
    const { error: authError } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: currentPassword,
    })

    if (authError) {
      throw new Error('Current password is incorrect')
    }

    // Update to new password
    const { error: updateError } = await supabase.auth.updateUser({
      password: newPassword,
    })

    if (updateError) throw updateError
    
    return { success: true, message: 'Password updated successfully' }
  } catch (error) {
    return { success: false, message: error instanceof Error ? error.message : 'Failed to update password' }
  }
}

export async function confirmPasswordReset(newPassword: string) {
  const supabase = await createClient()
  
  try {
    const { error } = await supabase.auth.updateUser({
      password: newPassword,
    })

    if (error) throw error
    
    redirect('/dashboard')
  } catch (error) {
    return { success: false, message: error instanceof Error ? error.message : 'Failed to reset password' }
  }
}
