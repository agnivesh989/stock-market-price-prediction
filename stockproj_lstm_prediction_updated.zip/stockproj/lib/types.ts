export interface Stock {
  id: string;
  symbol: string;
  name: string;
  sector: string;
  exchange: string;
  is_active: boolean;
}

export interface StockPrice {
  id: string;
  stock_id: string;
  date: string;
  open_price: number;
  high_price: number;
  low_price: number;
  close_price: number;
  adj_close: number;
  volume: number;
}

export interface Prediction {
  id: string;
  stock_id: string;
  user_id: string | null;
  prediction_date: string;
  predicted_price: number;
  actual_price: number | null;
  confidence: number;
  model_version: string;
  prediction_days: number;
  created_at: string;
}

export interface Profile {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
  created_at: string;
  updated_at: string;
}

export interface UserSettings {
  id: string;
  user_id: string;
  theme: 'dark' | 'light';
  default_stock_id: string | null;
  notification_enabled: boolean;
  chart_type: 'candlestick' | 'line' | 'area';
  prediction_days: number;
}

export interface StockData {
  symbol: string;
  name: string;
  sector: string;
  currentPrice: number;
  previousClose: number;
  change: number;
  changePercent: number;
  high52Week: number;
  low52Week: number;
  ma20: number;
  ma50: number;
  volume: number;
  avgVolume: number;
  marketCap: number;
  pe: number;
  history: {
    date: string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  }[];
  predictions?: number[];
  confidence?: number;
  modelVersion?: string;
}

// NSE Stocks constant
export const NSE_STOCKS = [
  { symbol: 'RELIANCE.NS', name: 'Reliance Industries', sector: 'Energy' },
  { symbol: 'TCS.NS', name: 'Tata Consultancy Services', sector: 'Technology' },
  { symbol: 'HDFCBANK.NS', name: 'HDFC Bank', sector: 'Banking' },
  { symbol: 'INFY.NS', name: 'Infosys', sector: 'Technology' },
  { symbol: 'ICICIBANK.NS', name: 'ICICI Bank', sector: 'Banking' },
  { symbol: 'HINDUNILVR.NS', name: 'Hindustan Unilever', sector: 'Consumer Goods' },
  { symbol: 'SBIN.NS', name: 'State Bank of India', sector: 'Banking' },
  { symbol: 'BHARTIARTL.NS', name: 'Bharti Airtel', sector: 'Telecommunications' },
  { symbol: 'KOTAKBANK.NS', name: 'Kotak Mahindra Bank', sector: 'Banking' },
  { symbol: 'ITC.NS', name: 'ITC Limited', sector: 'Consumer Goods' },
  { symbol: 'LT.NS', name: 'Larsen & Toubro', sector: 'Construction' },
  { symbol: 'AXISBANK.NS', name: 'Axis Bank', sector: 'Banking' },
  { symbol: 'WIPRO.NS', name: 'Wipro', sector: 'Technology' },
  { symbol: 'MARUTI.NS', name: 'Maruti Suzuki', sector: 'Automobile' },
  { symbol: 'TATASTEEL.NS', name: 'Tata Steel', sector: 'Metals' },
] as const;
