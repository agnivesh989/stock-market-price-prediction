# Phase 3: Live Chart Updates & Data Persistence

## Overview

Phase 3 adds persistent storage of market data to the database and real-time chart updates in the frontend. Historical data is now saved to Supabase for analysis and backtesting.

## Architecture

```
Zerodha Kite ──→ Backend ──→ Supabase (persistence)
                    ↓
                Socket.IO ──→ Frontend (live charts)
```

## Database Schema (Supabase)

The `stock_prices` table (created in Phase 1) is now actively used:

```sql
CREATE TABLE stock_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stock_id UUID NOT NULL REFERENCES stocks(id),
  date DATE NOT NULL,
  open_price DECIMAL(18, 4),
  high_price DECIMAL(18, 4),
  low_price DECIMAL(18, 4),
  close_price DECIMAL(18, 4),
  adj_close DECIMAL(18, 4),
  volume BIGINT,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(stock_id, date)
);
```

## Implementation Steps

### Step 1: Create Data Persistence Service

File: `backend/src/services/database.ts`

```typescript
import { createClient } from '@supabase/supabase-js'

export async function saveCandle(
  supabase: any,
  stockId: string,
  candle: Candle,
  date: Date
) {
  const { error } = await supabase
    .from('stock_prices')
    .upsert({
      stock_id: stockId,
      date: date.toISOString().split('T')[0],
      open_price: candle.open,
      high_price: candle.high,
      low_price: candle.low,
      close_price: candle.close,
      volume: candle.volume,
    }, { onConflict: 'stock_id,date' })

  if (error) {
    console.error('[Database] Error saving candle:', error)
  }
}
```

### Step 2: Update Backend Server

Modify `backend/src/server.ts`:

```typescript
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
)

// Save each candle to database
setInterval(async () => {
  for (const [stockId, aggregator] of candleAggregators) {
    const candles = getLastCandles(aggregator, 1)
    for (const candle of candles) {
      await saveCandle(supabase, stockId, candle, new Date(candle.timestamp * 1000))
    }
  }
}, 60000) // Every minute
```

### Step 3: Update Frontend Hooks

File: `lib/socket-client.ts`

Add historical data fetching:

```typescript
export function useHistoricalData(symbol: string | null, days: number = 30) {
  const socket = useSocket()
  const [historicalData, setHistoricalData] = useState<any[]>([])

  useEffect(() => {
    if (!socket || !symbol) return

    // Request historical data from backend
    socket.emit('historical-data-request', {
      symbol,
      fromDate: new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      toDate: new Date().toISOString().split('T')[0],
      interval: 'day'
    })

    socket.on('historical-data-response', (data: any) => {
      if (data.symbol === symbol) {
        setHistoricalData(data.data)
      }
    })

    return () => {
      socket.off('historical-data-response')
    }
  }, [socket, symbol, days])

  return historicalData
}
```

### Step 4: Update Dashboard Component

Use historical data in charts:

```typescript
import { StockChart } from '@/components/stock-chart'
import { useHistoricalData, useStockLiveData } from '@/lib/socket-client'

export function DashboardChart({ symbol }: { symbol: string }) {
  const { liveData } = useStockLiveData(symbol)
  const historicalData = useHistoricalData(symbol, 90)

  return (
    <StockChart
      data={historicalData}
      title={`${symbol} - 90 Days`}
      predictions={liveData ? [liveData.ltp] : undefined}
    />
  )
}
```

## Environment Variables

Update `.env` files:

```env
# backend/.env
SUPABASE_URL=your_supabase_url
SUPABASE_SERVICE_KEY=your_service_key
SUPABASE_ANON_KEY=your_anon_key
```

## Testing Phase 3

### 1. Verify Data Persistence
```bash
# Check Supabase database
# Go to: https://app.supabase.com → stock_prices table
# Should see new records appearing every minute
```

### 2. Check Historical Charts
1. Open Dashboard
2. Select a stock
3. Chart should show 90 days of historical data
4. Live price should update on the chart

### 3. Monitor Database Writes
In Supabase dashboard:
```
stock_prices table:
- Count should increase ~15 records/minute (15 stocks)
- Dates should be today
- Prices should match current market
```

## Query Optimization

### Indexes for Performance
```sql
-- Create indexes for faster queries
CREATE INDEX idx_stock_prices_stock_date 
  ON stock_prices(stock_id, date DESC);

CREATE INDEX idx_stock_prices_created_at 
  ON stock_prices(created_at DESC);
```

### Data Retention Policy
```sql
-- Archive old data (keep 2 years)
DELETE FROM stock_prices 
WHERE created_at < NOW() - INTERVAL '2 years';
```

## Performance Impact

| Metric | Before | After |
|--------|--------|-------|
| Backend Memory | ~10MB | ~50MB |
| API Calls/min | ~60 | ~120 |
| Chart Load Time | <100ms | 200-500ms |
| Data Storage | 0 | ~5MB/month |

## Troubleshooting

### Issue: Supabase Connection Failed
**Error**: `Connection refused`

**Solution**:
1. Verify SUPABASE_URL is correct
2. Check SUPABASE_SERVICE_KEY is valid
3. Restart backend

### Issue: Duplicate Key Error
**Error**: `duplicate key value violates unique constraint`

**Solution**:
Already handled by `onConflict: 'stock_id,date'` in upsert

### Issue: Slow Chart Rendering
**Error**: Charts take >1 second to load

**Solution**:
1. Add database indexes
2. Limit historical data to 90 days
3. Implement client-side pagination

## Next: Phase 4

With Phase 3 complete, you have:
- Real-time market data (Phase 2)
- Historical data persistence (Phase 3)
- Live charts updated (Phase 3)

Next: Add LSTM predictions on top of this data.
