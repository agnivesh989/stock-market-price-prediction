import json
import math
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List

import numpy as np
import torch
import torch.nn as nn

BASE_STOCKS = {
    'RELIANCE.NS': { 'name': 'Reliance Industries', 'sector': 'Energy', 'basePrice': 2847.55 },
    'TCS.NS': { 'name': 'Tata Consultancy Services', 'sector': 'Technology', 'basePrice': 4125.30 },
    'HDFCBANK.NS': { 'name': 'HDFC Bank', 'sector': 'Banking', 'basePrice': 1678.45 },
    'INFY.NS': { 'name': 'Infosys', 'sector': 'Technology', 'basePrice': 1845.90 },
    'ICICIBANK.NS': { 'name': 'ICICI Bank', 'sector': 'Banking', 'basePrice': 1198.75 },
    'HINDUNILVR.NS': { 'name': 'Hindustan Unilever', 'sector': 'Consumer Goods', 'basePrice': 2456.30 },
    'SBIN.NS': { 'name': 'State Bank of India', 'sector': 'Banking', 'basePrice': 825.45 },
    'BHARTIARTL.NS': { 'name': 'Bharti Airtel', 'sector': 'Telecommunications', 'basePrice': 1532.80 },
    'KOTAKBANK.NS': { 'name': 'Kotak Mahindra Bank', 'sector': 'Banking', 'basePrice': 1756.30 },
    'ITC.NS': { 'name': 'ITC Limited', 'sector': 'Consumer Goods', 'basePrice': 457.25 },
    'LT.NS': { 'name': 'Larsen & Toubro', 'sector': 'Construction', 'basePrice': 3487.60 },
    'AXISBANK.NS': { 'name': 'Axis Bank', 'sector': 'Banking', 'basePrice': 1089.90 },
    'WIPRO.NS': { 'name': 'Wipro', 'sector': 'Technology', 'basePrice': 503.80 },
    'MARUTI.NS': { 'name': 'Maruti Suzuki', 'sector': 'Automobile', 'basePrice': 8976.45 },
    'TATASTEEL.NS': { 'name': 'Tata Steel', 'sector': 'Metals', 'basePrice': 1287.30 },
}

OUTPUT_PATH = Path(__file__).with_name('lstm_predictions.json')
LOOKBACK_DAYS = 60
FORECAST_DAYS = 7
SEQUENCE_LENGTH = 12


def symbol_hash(symbol: str) -> int:
    return sum((idx + 1) * ord(char) for idx, char in enumerate(symbol))


def build_deterministic_history(symbol: str, base_price: float, days: int = LOOKBACK_DAYS) -> List[float]:
    h = symbol_hash(symbol)
    slope = ((h % 11) - 5) * 0.0006
    season_a = 0.017 + (h % 5) * 0.002
    season_b = 0.009 + (h % 7) * 0.0015
    phase_a = (h % 17) / 4.0
    phase_b = (h % 23) / 5.0

    prices: List[float] = []
    for i in range(days):
        trend = 1 + slope * (i - days / 2)
        cyclical = 1 + season_a * math.sin((i / 4.2) + phase_a) + season_b * math.cos((i / 8.8) + phase_b)
        micro = 1 + 0.0035 * math.sin((i / 2.1) + phase_b / 2)
        price = base_price * trend * cyclical * micro
        prices.append(round(price, 2))
    return prices


class StockLSTM(nn.Module):
    def __init__(self, hidden_size: int = 8):
        super().__init__()
        self.lstm = nn.LSTM(input_size=1, hidden_size=hidden_size, num_layers=1, batch_first=True)
        self.dropout = nn.Dropout(0.05)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out, _ = self.lstm(x)
        out = self.dropout(out[:, -1, :])
        return self.fc(out)


def minmax_scale(values: np.ndarray):
    min_v = float(values.min())
    max_v = float(values.max())
    scale = max(max_v - min_v, 1e-6)
    scaled = (values - min_v) / scale
    return scaled, min_v, scale


def inverse_scale(values: List[float], min_v: float, scale: float) -> List[float]:
    return [round(float(v) * scale + min_v, 2) for v in values]


def train_and_forecast(prices: List[float]) -> Dict[str, object]:
    torch.set_num_threads(1)
    torch.manual_seed(42)
    np.random.seed(42)

    arr = np.array(prices, dtype=np.float32)
    scaled, min_v, scale = minmax_scale(arr)

    X, y = [], []
    for i in range(len(scaled) - SEQUENCE_LENGTH):
        X.append(scaled[i:i + SEQUENCE_LENGTH])
        y.append(scaled[i + SEQUENCE_LENGTH])

    X_tensor = torch.tensor(np.array(X)[:, :, None], dtype=torch.float32)
    y_tensor = torch.tensor(np.array(y)[:, None], dtype=torch.float32)

    model = StockLSTM(hidden_size=8)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.02)
    loss_fn = nn.MSELoss()

    model.train()
    last_loss = 0.0
    for _ in range(12):
        optimizer.zero_grad()
        preds = model(X_tensor)
        loss = loss_fn(preds, y_tensor)
        loss.backward()
        optimizer.step()
        last_loss = float(loss.item())

    model.eval()
    forecast_scaled: List[float] = []
    window = torch.tensor(scaled[-SEQUENCE_LENGTH:].reshape(1, SEQUENCE_LENGTH, 1), dtype=torch.float32)
    with torch.no_grad():
        for _ in range(FORECAST_DAYS):
            next_value = float(model(window).item())
            next_value = max(0.0, min(1.2, next_value))
            forecast_scaled.append(next_value)
            next_tensor = torch.tensor([[[next_value]]], dtype=torch.float32)
            window = torch.cat([window[:, 1:, :], next_tensor], dim=1)

    raw_predictions = inverse_scale(forecast_scaled, min_v, scale)
    last_close = prices[-1]
    relative_changes = [round((pred / last_close) - 1, 6) for pred in raw_predictions]

    confidence = max(72.0, min(96.0, round(94.0 - (last_loss * 120), 1)))

    return {
        'historyLastClose': round(last_close, 2),
        'predictions': raw_predictions,
        'relativeChanges': relative_changes,
        'confidence': confidence,
        'modelVersion': 'PyTorch LSTM v1.0',
        'trainedAt': datetime.utcnow().isoformat() + 'Z',
    }


def main() -> None:
    all_predictions: Dict[str, object] = {}
    for symbol, info in BASE_STOCKS.items():
        history = build_deterministic_history(symbol, info['basePrice'])
        all_predictions[symbol] = train_and_forecast(history)

    with OUTPUT_PATH.open('w', encoding='utf-8') as f:
        json.dump(all_predictions, f, indent=2)

    print(f'Saved LSTM predictions to {OUTPUT_PATH}')


if __name__ == '__main__':
    main()
