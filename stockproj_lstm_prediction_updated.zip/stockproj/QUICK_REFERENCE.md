# StockAI - Quick Reference Guide

## 🎯 Quick Setup (5 Minutes)

```bash
# 1. Install dependencies
pnpm install
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt

# 2. Setup .env.local with Supabase keys
# 3. Run seed scripts in Supabase SQL Editor
# 4. Start server
pnpm dev

# 5. Open http://localhost:3000
```

---

## 📱 User Features

| Feature | Access | Notes |
|---------|--------|-------|
| Register | / → Sign Up | Email, password, name, phone |
| Login | / → Login | Email & password |
| Dashboard | /dashboard | Main analytics view |
| Stock Selection | Dropdown | 15 NSE stocks |
| Charts | Dashboard | 4 types: Area, Line, Candlestick, Bar |
| Time Periods | Chart buttons | 1D, 1W, 1M, 3M, 6M, 1Y |
| Predictions | Right panel | 7-day AI forecast |
| Settings | /dashboard/settings | Theme, chart type, preferences |
| Profile | /dashboard/profile | Name, email, phone, password change |
| Theme | Sidebar icon | Light/Dark mode toggle |

---

## 🔐 Password Management

**Register Password**:
- Any 6+ character password allowed

**Change Password** (Profile page):
- Must enter current password
- New password requires:
  - 8+ characters
  - 1 uppercase letter
  - 1 lowercase letter
  - 1 number
  - 1 special character

**Reset Forgotten Password** (Login page):
- "Forgot Password" link
- Email reset link sent
- Create new password with above requirements

---

## 📊 Chart Types

### Area Chart (Default)
- Filled area under price line
- Good for trends
- Shows volume via area fill

### Line Chart
- Simple price line
- Clean, minimal
- Best for comparing multiple values

### Candlestick Chart
- High/Low/Open/Close bars
- Traditional trading view
- Detailed price movement

### Bar Chart
- Volume bars
- Time-series comparison
- Good for volume analysis

---

## ⏰ Time Periods

| Button | Period | Days | Use Case |
|--------|--------|------|----------|
| 1D | 1 Day | 1 | Intraday movements |
| 1W | 1 Week | 7 | Weekly trends |
| 1M | 1 Month | 30 | Monthly analysis |
| 3M | 3 Months | 90 | Quarterly performance |
| 6M | 6 Months | 180 | Semi-annual trends |
| 1Y | 1 Year | 365 | Annual comparison |

---

## 🧮 Dashboard Stats Shown

- **Current Price**: Latest closing price
- **Change**: Price change in rupees
- **Change %**: Percentage change (green/red)
- **52-Week High/Low**: Annual range
- **Volume**: Trading volume
- **Avg Volume**: Average trading volume
- **MA20**: 20-day moving average
- **MA50**: 50-day moving average
- **Market Cap**: Company valuation
- **P/E Ratio**: Valuation multiple

---

## 🎨 Theme Colors

### Dark Theme (Default)
- Background: #0f1419 (very dark blue-gray)
- Cards: #1a2332 (dark blue-gray)
- Text: #ffffff (white)
- Chart: #3b82f6 (bright blue)

### Light Theme
- Background: #ffffff (white)
- Cards: #f1f5f9 (light gray-blue)
- Text: #0f1419 (dark)
- Chart: #3b82f6 (bright blue)

---

## 📁 Important Files

| File | Purpose | Edit? |
|------|---------|-------|
| `.env.local` | Supabase keys | ✅ Yes |
| `app/globals.css` | Theme colors | ✅ Yes |
| `lib/types.ts` | Data types & stocks | ✅ If adding stocks |
| `components/stock-chart.tsx` | Chart logic | ❌ No |
| `app/api/stocks/route.ts` | Data endpoint | ❌ No |
| `TECHNICAL_REPORT.md` | Full documentation | 📖 Reference |

---

## 🔗 Important URLs

| Purpose | URL |
|---------|-----|
| Application | http://localhost:3000 |
| Dashboard | http://localhost:3000/dashboard |
| Settings | http://localhost:3000/dashboard/settings |
| Profile | http://localhost:3000/dashboard/profile |
| API Endpoint | http://localhost:3000/api/stocks |

---

## 🚀 Deployment

```bash
# Build for production
pnpm build

# Test production build locally
pnpm start

# Deploy to Vercel
vercel deploy --prod

# Set environment variables
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
```

---

## 🐛 Quick Fixes

**Chart not showing?**
```bash
Ctrl+Shift+Delete → Clear cache → Refresh page
```

**Port 3000 in use?**
```bash
# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Mac/Linux
lsof -ti:3000 | xargs kill -9
```

**Database errors?**
```bash
1. Verify Supabase URL and keys in .env.local
2. Check database is seeded (all 8 scripts run)
3. Test connection with VS Code PostgreSQL extension
```

**Theme not switching?**
```bash
localStorage.clear()
Refresh page (Ctrl+F5)
```

---

## 📝 API Responses

### Stock Data Endpoint
```
GET /api/stocks?symbol=RELIANCE.NS&period=1M
```

Response:
```json
{
  "symbol": "RELIANCE.NS",
  "name": "Reliance Industries",
  "currentPrice": 2875.50,
  "change": 45.25,
  "changePercent": 1.60,
  "predictions": [2880, 2885, 2890, 2895, 2900, 2905, 2910],
  "history": [
    {
      "date": "2024-01-01",
      "open": 2830.00,
      "high": 2885.00,
      "low": 2828.00,
      "close": 2875.50,
      "volume": 50000000
    }
  ]
}
```

---

## 🔑 Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `/` | Focus search (if available) |
| `Ctrl+K` | Command palette |
| `Ctrl+/` | Toggle developer console |
| `F12` | Open DevTools |
| `Ctrl+Shift+R` | Hard refresh |

---

## 📊 15 NSE Stocks Included

1. **RELIANCE.NS** - Reliance Industries (Energy)
2. **TCS.NS** - Tata Consultancy Services (Technology)
3. **HDFCBANK.NS** - HDFC Bank (Banking)
4. **INFY.NS** - Infosys (Technology)
5. **ICICIBANK.NS** - ICICI Bank (Banking)
6. **HINDUNILVR.NS** - Hindustan Unilever (Consumer)
7. **SBIN.NS** - State Bank of India (Banking)
8. **BHARTIARTL.NS** - Bharti Airtel (Telecom)
9. **KOTAKBANK.NS** - Kotak Mahindra Bank (Banking)
10. **ITC.NS** - ITC Limited (Consumer)
11. **LT.NS** - Larsen & Toubro (Construction)
12. **AXISBANK.NS** - Axis Bank (Banking)
13. **WIPRO.NS** - Wipro (Technology)
14. **MARUTI.NS** - Maruti Suzuki (Automobile)
15. **TATASTEEL.NS** - Tata Steel (Metals)

---

## 🎓 Learning Path

1. **Day 1**: Setup & Basic Navigation
   - Install dependencies
   - Run dev server
   - Register & login
   - Explore dashboard

2. **Day 2**: Features Deep Dive
   - Try all 4 chart types
   - Test time periods
   - Change settings
   - View predictions

3. **Day 3**: Administration
   - Change password
   - Update profile
   - Modify preferences
   - Deploy to production

---

## 📞 Getting Help

**Documentation**:
- README.md - Setup & basic info
- TECHNICAL_REPORT.md - Full technical details
- PROJECT_SUMMARY.md - What was fixed & why
- This file - Quick reference

**Browser Dev Tools** (F12):
- Console tab - Error messages
- Network tab - API calls
- Application tab - localStorage/cookies

**Common Issues**:
```
Issue: 404 on /dashboard
Fix: Make sure you're logged in

Issue: Stocks not loading
Fix: Check Supabase connection in .env.local

Issue: Charts empty
Fix: Verify API working in Network tab (F12)

Issue: Settings don't apply
Fix: Hard refresh (Ctrl+Shift+R) and try again
```

---

## ✅ Verification Checklist

Before going live:

- [ ] All 8 SQL scripts executed in Supabase
- [ ] .env.local has Supabase URL and key
- [ ] Can register new account
- [ ] Can login with account
- [ ] Dashboard loads with stock data
- [ ] Charts render correctly (not too dark)
- [ ] Time period buttons work
- [ ] Chart type changes apply
- [ ] Theme toggle switches Dark/Light
- [ ] Password change works
- [ ] All 15 stocks appear in dropdown
- [ ] Predictions display correctly

---

## 🚀 Production Checklist

Before deploying to production:

- [ ] Run `pnpm build` - builds successfully
- [ ] Run `pnpm lint` - no linting errors
- [ ] Set all environment variables on Vercel
- [ ] Test login on production URL
- [ ] Verify database connection in production
- [ ] Monitor error logs (Vercel dashboard)
- [ ] Check Lighthouse scores (target: >90)
- [ ] Test on mobile devices
- [ ] Verify HTTPS is enabled
- [ ] Setup monitoring/alerts

---

## 📈 Performance Tips

1. **Database**: Add indexes for frequently queried columns
2. **Charts**: Use memoization to prevent re-renders
3. **Images**: Optimize and use next/image
4. **API**: Implement response caching
5. **Bundle**: Analyze bundle size with `pnpm analyze`

---

**Last Updated**: March 2026  
**Version**: 1.0  
**Status**: ✅ Production Ready
