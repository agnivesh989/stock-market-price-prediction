-- Create profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name TEXT,
  last_name TEXT,
  email TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create stocks table
CREATE TABLE IF NOT EXISTS public.stocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  exchange TEXT DEFAULT 'NSE',
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create stock_prices table
CREATE TABLE IF NOT EXISTS public.stock_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stock_id UUID REFERENCES public.stocks(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  open_price DECIMAL(12,2),
  high_price DECIMAL(12,2),
  low_price DECIMAL(12,2),
  close_price DECIMAL(12,2),
  volume BIGINT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(stock_id, date)
);

-- Create predictions table
CREATE TABLE IF NOT EXISTS public.predictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stock_id UUID REFERENCES public.stocks(id) ON DELETE CASCADE,
  prediction_date DATE NOT NULL,
  predicted_price DECIMAL(12,2) NOT NULL,
  actual_price DECIMAL(12,2),
  confidence DECIMAL(5,4),
  model_version TEXT DEFAULT 'v1',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create user_settings table
CREATE TABLE IF NOT EXISTS public.user_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  theme TEXT DEFAULT 'system',
  default_stock_id UUID REFERENCES public.stocks(id),
  notifications_enabled BOOLEAN DEFAULT TRUE,
  prediction_days INTEGER DEFAULT 7,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Stocks policies (public read)
CREATE POLICY "stocks_select_all" ON public.stocks FOR SELECT TO authenticated USING (TRUE);

-- Stock prices policies (public read)
CREATE POLICY "stock_prices_select_all" ON public.stock_prices FOR SELECT TO authenticated USING (TRUE);

-- Predictions policies (public read)
CREATE POLICY "predictions_select_all" ON public.predictions FOR SELECT TO authenticated USING (TRUE);

-- User settings policies
CREATE POLICY "user_settings_select_own" ON public.user_settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "user_settings_insert_own" ON public.user_settings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "user_settings_update_own" ON public.user_settings FOR UPDATE USING (auth.uid() = user_id);

-- Profile creation trigger
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, first_name, last_name, email)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'first_name', ''),
    COALESCE(NEW.raw_user_meta_data ->> 'last_name', ''),
    NEW.email
  )
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.user_settings (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Insert NSE stocks
INSERT INTO public.stocks (symbol, name, exchange) VALUES
  ('RELIANCE.NS', 'Reliance Industries', 'NSE'),
  ('TCS.NS', 'Tata Consultancy Services', 'NSE'),
  ('HDFCBANK.NS', 'HDFC Bank', 'NSE'),
  ('INFY.NS', 'Infosys', 'NSE'),
  ('ICICIBANK.NS', 'ICICI Bank', 'NSE'),
  ('HINDUNILVR.NS', 'Hindustan Unilever', 'NSE'),
  ('SBIN.NS', 'State Bank of India', 'NSE'),
  ('BHARTIARTL.NS', 'Bharti Airtel', 'NSE'),
  ('ITC.NS', 'ITC Limited', 'NSE'),
  ('KOTAKBANK.NS', 'Kotak Mahindra Bank', 'NSE'),
  ('LT.NS', 'Larsen & Toubro', 'NSE'),
  ('AXISBANK.NS', 'Axis Bank', 'NSE'),
  ('WIPRO.NS', 'Wipro', 'NSE'),
  ('ASIANPAINT.NS', 'Asian Paints', 'NSE'),
  ('MARUTI.NS', 'Maruti Suzuki', 'NSE')
ON CONFLICT (symbol) DO NOTHING;
