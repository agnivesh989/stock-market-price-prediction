-- Create predictions table for storing LSTM predictions
CREATE TABLE IF NOT EXISTS public.predictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stock_id UUID NOT NULL REFERENCES public.stocks(id) ON DELETE CASCADE,
  prediction_date DATE NOT NULL,
  predicted_price DECIMAL(12, 4) NOT NULL,
  actual_price DECIMAL(12, 4),
  model_accuracy DECIMAL(5, 4),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(stock_id, prediction_date)
);

-- Enable RLS for predictions
ALTER TABLE public.predictions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "predictions_select_all" ON public.predictions FOR SELECT TO authenticated USING (true);
CREATE POLICY "predictions_insert_all" ON public.predictions FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "predictions_update_all" ON public.predictions FOR UPDATE TO authenticated USING (true);
