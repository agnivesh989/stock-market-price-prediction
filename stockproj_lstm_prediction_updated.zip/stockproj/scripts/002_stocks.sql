-- Create stocks table for storing stock information
CREATE TABLE IF NOT EXISTS public.stocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  sector TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS for stocks (public read access)
ALTER TABLE public.stocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "stocks_select_all" ON public.stocks FOR SELECT TO authenticated USING (true);
CREATE POLICY "stocks_insert_all" ON public.stocks FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "stocks_update_all" ON public.stocks FOR UPDATE TO authenticated USING (true);
