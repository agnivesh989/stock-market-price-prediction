"""
LSTM Stock Price Prediction Model
This script fetches historical stock data using yfinance and trains an LSTM model.
"""

import json
import sys
import os
from datetime import datetime, timedelta

# Install required packages
os.system('pip install yfinance numpy pandas scikit-learn tensorflow keras --quiet')

import yfinance as yf
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error

# Suppress TensorFlow warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping

# 15 NSE Stocks
NSE_STOCKS = [
    'RELIANCE.NS', 'TCS.NS', 'HDFCBANK.NS', 'INFY.NS', 'ICICIBANK.NS',
    'HINDUNILVR.NS', 'SBIN.NS', 'BHARTIARTL.NS', 'KOTAKBANK.NS', 'ITC.NS',
    'LT.NS', 'AXISBANK.NS', 'WIPRO.NS', 'MARUTI.NS', 'TATASTEEL.NS'
]


def fetch_stock_data(symbol, period='2y'):
    """Fetch historical stock data using yfinance"""
    try:
        stock = yf.Ticker(symbol)
        df = stock.history(period=period)
        if df.empty:
            print(f"No data found for {symbol}")
            return None
        df = df.reset_index()
        df['Date'] = pd.to_datetime(df['Date']).dt.tz_localize(None)
        return df[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']]
    except Exception as e:
        print(f"Error fetching {symbol}: {e}")
        return None


def prepare_data(data, look_back=60):
    """Prepare data for LSTM model"""
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(data['Close'].values.reshape(-1, 1))
    
    X, y = [], []
    for i in range(look_back, len(scaled_data)):
        X.append(scaled_data[i-look_back:i, 0])
        y.append(scaled_data[i, 0])
    
    X, y = np.array(X), np.array(y)
    X = np.reshape(X, (X.shape[0], X.shape[1], 1))
    
    return X, y, scaler


def build_lstm_model(look_back=60):
    """Build LSTM model architecture"""
    model = Sequential([
        LSTM(units=50, return_sequences=True, input_shape=(look_back, 1)),
        Dropout(0.2),
        LSTM(units=50, return_sequences=True),
        Dropout(0.2),
        LSTM(units=50, return_sequences=False),
        Dropout(0.2),
        Dense(units=25),
        Dense(units=1)
    ])
    
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model


def train_model(symbol, look_back=60, epochs=50, batch_size=32):
    """Train LSTM model for a stock"""
    print(f"\n{'='*50}")
    print(f"Training LSTM model for {symbol}")
    print(f"{'='*50}")
    
    # Fetch data
    data = fetch_stock_data(symbol)
    if data is None or len(data) < look_back + 10:
        return None
    
    # Prepare data
    X, y, scaler = prepare_data(data, look_back)
    
    # Split data
    train_size = int(len(X) * 0.8)
    X_train, X_test = X[:train_size], X[train_size:]
    y_train, y_test = y[:train_size], y[train_size:]
    
    # Build and train model
    model = build_lstm_model(look_back)
    
    early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
    
    history = model.fit(
        X_train, y_train,
        epochs=epochs,
        batch_size=batch_size,
        validation_data=(X_test, y_test),
        callbacks=[early_stop],
        verbose=1
    )
    
    # Evaluate model
    predictions = model.predict(X_test)
    predictions = scaler.inverse_transform(predictions)
    y_test_actual = scaler.inverse_transform(y_test.reshape(-1, 1))
    
    rmse = np.sqrt(mean_squared_error(y_test_actual, predictions))
    mae = mean_absolute_error(y_test_actual, predictions)
    
    print(f"\nModel Performance for {symbol}:")
    print(f"RMSE: {rmse:.2f}")
    print(f"MAE: {mae:.2f}")
    
    return {
        'model': model,
        'scaler': scaler,
        'rmse': rmse,
        'mae': mae,
        'last_data': data['Close'].values[-look_back:],
        'current_price': data['Close'].values[-1],
        'dates': data['Date'].values
    }


def predict_future(model_data, days=7, look_back=60):
    """Predict future stock prices"""
    model = model_data['model']
    scaler = model_data['scaler']
    last_data = model_data['last_data']
    
    predictions = []
    current_input = scaler.transform(last_data.reshape(-1, 1))
    
    for _ in range(days):
        input_reshaped = np.reshape(current_input[-look_back:], (1, look_back, 1))
        pred = model.predict(input_reshaped, verbose=0)
        predictions.append(pred[0, 0])
        current_input = np.append(current_input, pred)
    
    predictions = scaler.inverse_transform(np.array(predictions).reshape(-1, 1))
    return predictions.flatten()


def main():
    """Main function to train models and generate predictions"""
    results = {}
    
    for symbol in NSE_STOCKS:
        try:
            model_data = train_model(symbol, epochs=25, batch_size=32)
            if model_data:
                # Predict next 7 days
                future_predictions = predict_future(model_data, days=7)
                
                # Get historical data for chart
                historical_data = fetch_stock_data(symbol)
                
                results[symbol] = {
                    'current_price': float(model_data['current_price']),
                    'predictions': future_predictions.tolist(),
                    'rmse': float(model_data['rmse']),
                    'mae': float(model_data['mae']),
                    'historical': {
                        'dates': [d.strftime('%Y-%m-%d') if hasattr(d, 'strftime') else str(d)[:10] for d in historical_data['Date'].values[-30:]],
                        'prices': historical_data['Close'].values[-30:].tolist()
                    }
                }
                
                print(f"\n{symbol} - Current: {model_data['current_price']:.2f}")
                print(f"7-day predictions: {future_predictions}")
        except Exception as e:
            print(f"Error processing {symbol}: {e}")
            continue
    
    # Save results to JSON
    output_path = 'predictions_output.json'
    with open(output_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to {output_path}")
    print(f"Total stocks processed: {len(results)}")
    
    return results


if __name__ == '__main__':
    main()
