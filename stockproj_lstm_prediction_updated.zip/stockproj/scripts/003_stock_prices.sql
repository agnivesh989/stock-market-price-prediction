-- Create stock_prices table for historical data
CREATE TABLE IF NOT EXISTS public.stock_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  stock_id UUID NOT NULL REFERENCES public.stocks(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  open DECIMAL(12, 4),
  high DECIMAL(12, 4),
  low DECIMAL(12, 4),
  close DECIMAL(12, 4),
  adj_close DECIMAL(12, 4),
  volume BIGINT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(stock_id, date)
);

-- Enable RLS for stock_prices
ALTER TABLE public.stock_prices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "stock_prices_select_all" ON public.stock_prices FOR SELECT TO authenticated USING (true);
CREATE POLICY "stock_prices_insert_all" ON public.stock_prices FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "stock_prices_update_all" ON public.stock_prices FOR UPDATE TO authenticated USING (true);
