-- Seed 15 NSE stocks
INSERT INTO public.stocks (symbol, name, sector) VALUES
  ('RELIANCE.NS', 'Reliance Industries Ltd', 'Energy'),
  ('TCS.NS', 'Tata Consultancy Services Ltd', 'Technology'),
  ('HDFCBANK.NS', 'HDFC Bank Ltd', 'Banking'),
  ('INFY.NS', 'Infosys Ltd', 'Technology'),
  ('ICICIBANK.NS', 'ICICI Bank Ltd', 'Banking'),
  ('HINDUNILVR.NS', 'Hindustan Unilever Ltd', 'Consumer Goods'),
  ('SBIN.NS', 'State Bank of India', 'Banking'),
  ('BHARTIARTL.NS', 'Bharti Airtel Ltd', 'Telecommunications'),
  ('ITC.NS', 'ITC Ltd', 'Consumer Goods'),
  ('KOTAKBANK.NS', 'Kotak Mahindra Bank Ltd', 'Banking'),
  ('LT.NS', 'Larsen & Toubro Ltd', 'Construction'),
  ('AXISBANK.NS', 'Axis Bank Ltd', 'Banking'),
  ('WIPRO.NS', 'Wipro Ltd', 'Technology'),
  ('ASIANPAINT.NS', 'Asian Paints Ltd', 'Consumer Goods'),
  ('MARUTI.NS', 'Maruti Suzuki India Ltd', 'Automobile')
ON CONFLICT (symbol) DO NOTHING;
