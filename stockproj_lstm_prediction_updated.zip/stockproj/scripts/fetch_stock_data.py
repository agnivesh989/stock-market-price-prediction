"""
Fetch historical stock data for 15 NSE stocks using yfinance
and output as JSON for the Next.js application
"""

import json
import os
from datetime import datetime, timedelta

# Install required packages
os.system('pip install yfinance pandas --quiet')

import yfinance as yf
import pandas as pd

# 15 NSE Stocks
NSE_STOCKS = {
    'RELIANCE.NS': {'name': 'Reliance Industries', 'sector': 'Energy'},
    'TCS.NS': {'name': 'Tata Consultancy Services', 'sector': 'Technology'},
    'HDFCBANK.NS': {'name': 'HDFC Bank', 'sector': 'Banking'},
    'INFY.NS': {'name': 'Infosys', 'sector': 'Technology'},
    'ICICIBANK.NS': {'name': 'ICICI Bank', 'sector': 'Banking'},
    'HINDUNILVR.NS': {'name': 'Hindustan Unilever', 'sector': 'Consumer Goods'},
    'SBIN.NS': {'name': 'State Bank of India', 'sector': 'Banking'},
    'BHARTIARTL.NS': {'name': 'Bharti Airtel', 'sector': 'Telecommunications'},
    'KOTAKBANK.NS': {'name': 'Kotak Mahindra Bank', 'sector': 'Banking'},
    'ITC.NS': {'name': 'ITC Limited', 'sector': 'Consumer Goods'},
    'LT.NS': {'name': 'Larsen & Toubro', 'sector': 'Construction'},
    'AXISBANK.NS': {'name': 'Axis Bank', 'sector': 'Banking'},
    'WIPRO.NS': {'name': 'Wipro', 'sector': 'Technology'},
    'MARUTI.NS': {'name': 'Maruti Suzuki', 'sector': 'Automobile'},
    'TATASTEEL.NS': {'name': 'Tata Steel', 'sector': 'Metals'}
}


def fetch_stock_data(symbol, period='1y'):
    """Fetch historical stock data using yfinance"""
    try:
        stock = yf.Ticker(symbol)
        df = stock.history(period=period)
        
        if df.empty:
            print(f"No data found for {symbol}")
            return None
        
        df = df.reset_index()
        df['Date'] = pd.to_datetime(df['Date']).dt.tz_localize(None)
        
        # Get stock info
        info = stock.info
        
        return {
            'history': df[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']],
            'info': info
        }
    except Exception as e:
        print(f"Error fetching {symbol}: {e}")
        return None


def main():
    """Main function to fetch all stock data"""
    all_data = {}
    
    for symbol, meta in NSE_STOCKS.items():
        print(f"Fetching data for {symbol}...")
        
        result = fetch_stock_data(symbol)
        
        if result:
            history = result['history']
            info = result['info']
            
            # Calculate metrics
            current_price = float(history['Close'].iloc[-1])
            prev_close = float(history['Close'].iloc[-2]) if len(history) > 1 else current_price
            change = current_price - prev_close
            change_percent = (change / prev_close) * 100 if prev_close else 0
            
            # 52-week high/low
            high_52w = float(history['High'].max())
            low_52w = float(history['Low'].min())
            
            # Moving averages
            ma_20 = float(history['Close'].rolling(window=20).mean().iloc[-1]) if len(history) >= 20 else current_price
            ma_50 = float(history['Close'].rolling(window=50).mean().iloc[-1]) if len(history) >= 50 else current_price
            
            all_data[symbol] = {
                'symbol': symbol,
                'name': meta['name'],
                'sector': meta['sector'],
                'currentPrice': current_price,
                'previousClose': prev_close,
                'change': change,
                'changePercent': change_percent,
                'high52Week': high_52w,
                'low52Week': low_52w,
                'ma20': ma_20,
                'ma50': ma_50,
                'volume': int(history['Volume'].iloc[-1]),
                'avgVolume': int(history['Volume'].mean()),
                'marketCap': info.get('marketCap', 0),
                'pe': info.get('trailingPE', 0),
                'history': [
                    {
                        'date': row['Date'].strftime('%Y-%m-%d'),
                        'open': float(row['Open']),
                        'high': float(row['High']),
                        'low': float(row['Low']),
                        'close': float(row['Close']),
                        'volume': int(row['Volume'])
                    }
                    for _, row in history.tail(90).iterrows()  # Last 90 days
                ]
            }
            
            print(f"  Current: {current_price:.2f}, Change: {change_percent:.2f}%")
    
    # Save to JSON
    output_path = 'stock_data.json'
    with open(output_path, 'w') as f:
        json.dump(all_data, f, indent=2)
    
    print(f"\nData saved to {output_path}")
    print(f"Total stocks: {len(all_data)}")
    
    return all_data


if __name__ == '__main__':
    main()
