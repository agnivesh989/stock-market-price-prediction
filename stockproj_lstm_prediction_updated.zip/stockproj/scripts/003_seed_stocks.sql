-- Seed 15 NSE stocks
INSERT INTO public.stocks (symbol, name, sector) VALUES
  ('RELIANCE.NS', 'Reliance Industries Ltd', 'Energy'),
  ('TCS.NS', 'Tata Consultancy Services Ltd', 'Information Technology'),
  ('HDFCBANK.NS', 'HDFC Bank Ltd', 'Financial Services'),
  ('INFY.NS', 'Infosys Ltd', 'Information Technology'),
  ('ICICIBANK.NS', 'ICICI Bank Ltd', 'Financial Services'),
  ('HINDUNILVR.NS', 'Hindustan Unilever Ltd', 'Consumer Goods'),
  ('SBIN.NS', 'State Bank of India', 'Financial Services'),
  ('BHARTIARTL.NS', 'Bharti Airtel Ltd', 'Telecommunications'),
  ('ITC.NS', 'ITC Ltd', 'Consumer Goods'),
  ('KOTAKBANK.NS', 'Kotak Mahindra Bank Ltd', 'Financial Services'),
  ('LT.NS', 'Larsen & Toubro Ltd', 'Construction'),
  ('AXISBANK.NS', 'Axis Bank Ltd', 'Financial Services'),
  ('WIPRO.NS', 'Wipro Ltd', 'Information Technology'),
  ('MARUTI.NS', 'Maruti Suzuki India Ltd', 'Automobile'),
  ('TATASTEEL.NS', 'Tata Steel Ltd', 'Metals')
ON CONFLICT (symbol) DO NOTHING;
