# Phase 2: Zerodha Kite WebSocket Integration

## Overview

Phase 2 replaces mock data from Phase 1 with real market data from Zerodha Kite API. The backend will stream actual NSE stock prices in real-time using Socket.IO.

## Architecture Changes

### From Phase 1 (Mock)
```
Backend generates random data → Frontend receives updates
```

### To Phase 2 (Real)
```
Zerodha Kite API → Backend → Socket.IO → Frontend receives real prices
```

## Prerequisites

1. Zerodha Account with Kite API enabled
2. API credentials:
   - `api_key` (from Zerodha Dashboard)
   - `access_token` (obtained via OAuth)
   - `public_token` (obtained via OAuth)

## Getting Zerodha Credentials

### Step 1: Create Zerodha Account
1. Go to https://kite.zerodha.com
2. Sign up with email/phone
3. Verify identity (PAN, bank account)

### Step 2: Enable Kite API
1. Go to https://kite.zerodha.com/connect/apps
2. Create new application
3. Get `api_key` from application details

### Step 3: Get Access Token
```bash
# Option A: Use Zerodha's OAuth flow
# Redirect to: https://kite.zerodha.com/connect/login?api_key=YOUR_API_KEY&v=3

# Option B: Use request token from Kite login
# See Zerodha Connect documentation
```

## Implementation

### File Structure
```
backend/src/
├── services/
│   └── zerodha.ts           (NEW - Kite API client)
├── utils/
│   ├── marketTime.ts        (existing)
│   ├── candles.ts          (NEW - candle aggregation)
│   └── ...
├── types/
│   └── socket-events.ts    (NEW - event types)
└── server.ts               (update with Zerodha integration)
```

### Key Changes to Backend

#### 1. Update package.json
Add axios (already in dependencies):
```json
{
  "dependencies": {
    "axios": "^1.6.2"
  }
}
```

#### 2. Create Zerodha Service
File: `backend/src/services/zerodha.ts`

Features:
- Authenticate with Zerodha API
- Fetch instrument tokens for NSE stocks
- Get real-time quotes
- Handle API errors gracefully

#### 3. Create Candle Aggregator
File: `backend/src/utils/candles.ts`

Features:
- Convert tick data to 1-min/5-min/15-min candles
- Maintain OHLCV data
- Keep last 500 candles in memory

#### 4. Update Server
File: `backend/src/server.ts`

Changes:
- Initialize Zerodha client on startup
- Replace `generateMockLiveData()` with real data
- Subscribe to Zerodha updates
- Broadcast via Socket.IO

## Setup Instructions

### 1. Update Backend Environment
```bash
# backend/.env
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:3000

# NEW: Zerodha Credentials
ZERODHA_API_KEY=your_api_key_here
ZERODHA_ACCESS_TOKEN=your_access_token_here
ZERODHA_PUBLIC_TOKEN=your_public_token_here
```

### 2. Modify server.ts

Replace the `generateMockLiveData()` function with:

```typescript
import { KiteClient, formatZerodhaQuote } from './services/zerodha'
import { createCandleAggregator, addTickToCandle } from './utils/candles'

const kiteClient = new KiteClient({
  apiKey: process.env.ZERODHA_API_KEY!,
  accessToken: process.env.ZERODHA_ACCESS_TOKEN!,
  publicToken: process.env.ZERODHA_PUBLIC_TOKEN!,
})

async function getLiveStockData(symbol: string) {
  try {
    const quote = await kiteClient.getQuote(symbol)
    return formatZerodhaQuote(symbol, quote)
  } catch (error) {
    console.error(`[Zerodha] Error fetching ${symbol}:`, error)
    // Fallback to last known data
    return null
  }
}
```

### 3. Update Socket Subscriptions

In the Socket.IO handler:

```typescript
socket.on('subscribe-stock', async (symbol: string) => {
  // Get initial data from Zerodha
  const initialData = await getLiveStockData(symbol)
  if (initialData) {
    socket.emit('stock-update', initialData)
  }

  // Poll for updates (adjust frequency based on Zerodha limits)
  const interval = setInterval(async () => {
    if (subscribedStocks.get(symbol)?.has(socket.id)) {
      const data = await getLiveStockData(symbol)
      if (data) {
        socket.emit('stock-update', data)
      }
    } else {
      clearInterval(interval)
    }
  }, 5000) // Update every 5 seconds (Zerodha rate limit)

  socket.on('disconnect', () => {
    clearInterval(interval)
  })
})
```

### 4. Restart Backend

```bash
cd backend
npm run dev
```

Expected output:
```
[2024-01-15T09:15:00.000Z] StockAI Realtime Backend listening on port 5000
[2024-01-15T09:15:00.000Z] Zerodha Kite client initialized
```

## Testing Phase 2

### 1. Verify Real Data
1. Open `http://localhost:3000/dashboard`
2. Select a stock
3. Watch prices update
4. Compare with actual NSE prices (kite.zerodha.com)

### 2. Monitor API Calls
In Terminal 1 (Backend), watch logs:
```
[2024-01-15T09:15:00.000Z] Fetching quote for RELIANCE from Zerodha
[2024-01-15T09:15:00.000Z] Zerodha price: ₹2800.45
[2024-01-15T09:15:01.000Z] Broadcasting to 12 clients
```

### 3. Check Rate Limits
Zerodha API rate limits:
- Quote API: 10 requests/second
- Historical: 100 requests/minute
- No hard limits for WebSocket

Adjust polling frequency if getting rate-limit errors.

## API Endpoints Added

### Get Quote
```typescript
await kiteClient.getQuote('RELIANCE')
// Returns: {last_price, bid, ask, ohlc, volume, ...}
```

### Get Historical Candles
```typescript
await kiteClient.getHistoricalData(
  'RELIANCE',
  '1', // interval in minutes
  '2024-01-01',
  '2024-01-15'
)
// Returns: [[timestamp, open, high, low, close, volume], ...]
```

## Common Issues

### Issue: Invalid API Key
**Error**: `401 Unauthorized`

**Solution**:
1. Verify API key in Zerodha dashboard
2. Check it hasn't been rotated
3. Restart backend after updating .env

### Issue: Access Token Expired
**Error**: `403 Forbidden`

**Solution**:
1. Re-authenticate via OAuth flow
2. Get new access token
3. Update .env and restart

### Issue: Rate Limit Exceeded
**Error**: `429 Too Many Requests`

**Solution**:
1. Increase polling interval (set to 5-10 sec)
2. Reduce number of subscribed stocks
3. Use candle API instead of quote API

### Issue: Symbol Not Found
**Error**: `404 Not Found`

**Solution**:
1. Verify symbol format: `RELIANCE` (not `RELIANCE.NS`)
2. Check symbol is in NSE (not BSE)
3. Verify trading is open

## Performance Improvements

### From Phase 1 → Phase 2

| Metric | Phase 1 | Phase 2 |
|--------|---------|---------|
| Data Accuracy | Mock | Real |
| Latency | <100ms | 100-500ms |
| Price Update | Random | Real market |
| Volume | Random | Real | 
| Bid/Ask | Simulated | Real spreads |
| OHLC | N/A | Available |

## Candle Aggregation

Phase 2 includes automatic candle generation:

```typescript
const aggregator = createCandleAggregator('RELIANCE', 60) // 1-min candles

// Each price update contributes to candle
addTickToCandle(aggregator, 2800.50, 1000)

// Get completed candles
const candles = getCandles(aggregator)
```

Supported intervals:
- 1 minute
- 5 minutes
- 15 minutes
- 1 hour
- 1 day

## Next Steps

After Phase 2 is working:

1. **Phase 3**: Add historical data persistence to database
2. **Phase 4**: Integrate LSTM predictions

## Monitoring & Debugging

### Check Real vs Mock
```bash
# Backend logs show:
# Phase 1: "Generated mock price: ₹2800.45"
# Phase 2: "Zerodha price: ₹2800.45"
```

### Monitor API Calls
```typescript
console.log(`[Zerodha] API calls: ${apiCallCount}/second`)
```

### Check Broker Connection
```bash
curl http://localhost:5000/api/zerodha-status
```

## Troubleshooting Checklist

- [ ] Zerodha account is active
- [ ] API key is valid and enabled
- [ ] Access token hasn't expired
- [ ] Backend can reach Zerodha servers
- [ ] NSE market is open (9:15-15:30 IST, weekdays)
- [ ] Stock symbols are correct (NSE format)
- [ ] No rate limiting is occurring
- [ ] Real prices match kite.zerodha.com

## Support

- **Zerodha Docs**: https://kite.trade/docs/connect/
- **Zerodha Support**: support@zerodha.com
- **Backend Issues**: Check backend logs in Terminal 1
