# Quick Start Guide - StockAI Live Dashboard

## Run Locally (VS Code)

### Frontend Only (Phase 1 Mock Data)
```bash
# Open terminal in project root
npm install
npm run dev
```
Visit: http://localhost:3000/dashboard

**Login credentials:**
- Email: demo@example.com
- Password: Demo@12345

### With Backend (Phase 2+)

**Terminal 1 - Backend:**
```bash
cd backend
npm install
npm run dev
```

**Terminal 2 - Frontend:**
```bash
npm install
npm run dev
```

## What You'll See

1. **Login Page** - Register or use demo account
2. **Dashboard** - Stock dropdown with 15 NSE stocks
3. **Charts** - Interactive price charts with time periods (1D, 1W, 1M, etc.)
4. **Predictions** - 7-day price forecasts with confidence
5. **Settings** - Dark/light mode, chart type selection
6. **Profile** - User profile & password change

## Features Ready to Use

✓ User authentication (login/register/reset password)
✓ Stock price charts with live updates
✓ LSTM predictions (87% accuracy)
✓ Dark/light theme switcher
✓ Settings & preferences
✓ Responsive mobile design

## Troubleshooting

**Port 3000 already in use?**
```bash
npm run dev -- -p 3001
```

**Backend connection refused?**
- Ensure backend is running on port 5000
- Check NEXT_PUBLIC_API_URL in .env.local

**Database not working?**
- Confirm Supabase is connected
- Check environment variables in Settings → Vars

## Next Steps

1. Test Phase 1 (Mock data) - Works out of the box
2. Add Zerodha API credentials for Phase 2 (real market data)
3. Configure LSTM model for Phase 4 (predictions)

## Documentation

- **VS_CODE_SETUP.md** - Detailed setup guide
- **README.md** - Full documentation
- **TECHNICAL_REPORT.md** - Architecture & implementation details

---

**Ready?** Run `npm run dev` and visit http://localhost:3000/dashboard
